<?php 

	$con=mysql_connect("db.beta.handandneedle.com","betahnn","-d3pqDeC") 	
	 or die("Could not connect db.beta.handandneedle.com host");
	
	$selected = mysql_select_db("betahnn",$con) 
 	 or die("Could not select betahnn");

 ?>